﻿using Microsoft.EntityFrameworkCore;
using AppointmentSchedulingAPI.Data;
using AppointmentSheduling.Domain.Entities;
using AppointmentSheduling.Domain.Repositories;


namespace AppointmentSheduling.Infrastructure
{
    public class UsersRepository : IUsersRepository
    {
        DataContext context;
       
        public UsersRepository(DataContext context_)
        {
            context = context_;
        }

        public async Task<List<Users>> GetUsersAllAsync()
        {
            var response = await context.Users.Where(x=> x.Id != (Guid.Empty)).ToListAsync();
            return response;
        }

        public async Task AddUserAsync(Users user)
        {
            await context.AddAsync(user);
            await context.SaveChangesAsync();
        }

        public Users GetUsersById(Guid Id)
        {
            Users response = context.Users.Where(x => x.Id.Equals(Id)).FirstOrDefault();
            return response;
        }

        public Users UpdateUsersById(Users user)
        {
            var response = context.Users.Where(x => x.Id.Equals(user.Id)).Count();

            if (response == 0)
            {
                return new Users();
            }
            else
            {
                var update = context.Update(user);
                context.SaveChangesAsync();
            }
            return user;
        }

        public string DeleteUsersById(string Id)
        {
            var response = context.Users.Where(x => x.Id.Equals(Guid.Parse(Id))).FirstOrDefault();
            context.Remove(response);
            context.SaveChangesAsync();
            return "Registro Eliminado";
        }
    }
}
