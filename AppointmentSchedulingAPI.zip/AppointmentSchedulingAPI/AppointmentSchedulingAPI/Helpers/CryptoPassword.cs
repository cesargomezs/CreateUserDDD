﻿using AppointmentSheduling.DTOs;
using System.Security.Cryptography;
using System.Text;

namespace AppointmentSheduling.Helpers
{
    public class CryptoPassword
    {

        public const string KEY_ENCRYPT_BYTES = "IniProyectoDDD";
        public const string KEY_ENCRYPT_VI = "FinProyectoDDD";

        public static byte[] EncryptStringToBytes(string str , byte[] Key, byte[] IV)
        {

            byte[] bytes = new byte[str.Length * sizeof(char)];
            System.Buffer.BlockCopy(str.ToCharArray(), 0, bytes, 0, bytes.Length);
            return bytes;

        }
        public static string EncodeBase64(string value)
        {
            var valueBytes = Encoding.UTF8.GetBytes(value);
            return Convert.ToBase64String(valueBytes);
        }

        public static string DecodeBase64(string value)
        {
            var valueBytes = System.Convert.FromBase64String(value);
            return Encoding.UTF8.GetString(valueBytes);
        }

    }
}
