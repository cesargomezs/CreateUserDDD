﻿using System.Text;

namespace AppointmentSheduling.Helpers
{
    public class Consts
    {
        /// <summary>
        /// Clave de encriptación de contraseñas
        /// </summary>
        /// 
        public const string KEY_ENCRYPT_BYTES = "IniProyectoDDD";
        public const string KEY_ENCRYPT_VI = "FinProyectoDDD";

    }
}
