﻿using AppointmentSheduling.Domain.Entities;
using AppointmentSheduling.Domain.Repositories;


namespace AppointmentSheduling.Queries
{
    public class UsersQueries
    {
        private readonly IUsersRepository usersRepository;

        public UsersQueries(IUsersRepository usersRepository)
        {
            this.usersRepository = usersRepository;
        }
        public async Task<List<Users>> GetUsersAllAsync()
        {
            var response = await usersRepository.GetUsersAllAsync();
            return response;
        }
        public Users GetUsersById(Guid Id)
        {
            var response = usersRepository.GetUsersById(Id);

            return response;
        }
        public Users UpdateUsersById(Users entries)
        {
            var response = usersRepository.UpdateUsersById(entries);

            return response;
        }

    }
}
