using AppointmentSheduling.Queries;
using Microsoft.EntityFrameworkCore;
using AppointmentSchedulingAPI.Data;
using AppointmentSheduling.Infrastructure;
using AppointmentSheduling.ApplicationServices;
using AppointmentSheduling.Domain.Repositories;
using AppointmentSheduling.Helpers;
using AppointmentSheduling.Domain.DomainEvents;
using AppointmentSheduling.Domain.Contracts;


var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

//byte[] numbers = { 0, 16, 104, 213 };
var decrypted = CryptoPassword.DecodeBase64(builder.Configuration.GetConnectionString("DefaultConnection"));

builder.Services.AddDbContext<DataContext>(options =>
{
    options.UseSqlServer(decrypted);
});

builder.Services.AddScoped<IUsersRepository, UsersRepository>();
builder.Services.AddScoped<UsersQueries>();
builder.Services.AddScoped<UsersAppService>();
builder.Services.AddScoped<IUsersEvents,UsersEvents>();


var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
