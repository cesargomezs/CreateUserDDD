﻿namespace AppointmentSheduling.Commands
{
    public record CreateUsersCommand(Guid id,string FirtsName,string LastName);
    
}
