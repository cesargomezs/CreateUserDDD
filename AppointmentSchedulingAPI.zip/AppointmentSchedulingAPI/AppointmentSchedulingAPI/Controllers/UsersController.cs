﻿using Microsoft.AspNetCore.Mvc;
using AppointmentSheduling.DTOs;
using AppointmentSheduling.Domain.Entities;
using AppointmentSheduling.ApplicationServices;


namespace AppointmentSchedulingAPI.Controllers
{
    /// <summary>
    /// Controller for administration example (create,read,update,delete)
    /// </summary>
    [ApiController]
    [Route("[controller]")]
    public class UsersController : ControllerBase
    {

        UsersAppService userAppservice;

        public UsersController(UsersAppService userAppservice_)
        {
            userAppservice = userAppservice_;
        }

        [HttpGet]
        [Route("GetAllUsers")]
        public ActionResult<List<Users>> GetAllUsers()
        {
            List<Users> getUser = userAppservice.GetUsersAllAsync().Result.ToList();
            return Ok(RequestResult<List<Users>>.CreateSuccessful(getUser));
        }

        [HttpPost]
        [Route("AddUser")]
        public async Task<IActionResult> AddUser(Users user)
        {

            await userAppservice.AddUser(user);
            return Ok(user);
        }

        [HttpGet]
        [Route("GetUsersById")]
        public RequestResult<Users> GetUsersById(Guid Id)
        {
            var getUserId = userAppservice.GetUsersById(Id);
            return getUserId;
        }

        [HttpPut]
        [Route("UpdateUsersById")]
        public RequestResult<Users> UpdateUsersById(Users entries)
        {
            var updateUser = userAppservice.UpdateUsersById(entries);
            return updateUser;
        }

        [HttpDelete]
        [Route("DeleteUsersById")]
        public RequestResult<string> DeleteUsersById(string Id)
        {
            var updateUser = userAppservice.DeleteUsersById(Id);
            return updateUser;
        }
    }
}
