﻿using AppointmentSheduling.Domain.DomainEvents;

namespace AppointmentSheduling.Domain.Entities
{
    public class Users
    {
        /// <summary>
        /// Guid database
        /// </summary>
        public Guid Id { get; set; }
        /// <summary>
        /// Firts Name of User
        /// </summary>
        public string FirtsName { get; set; }
        /// <summary>
        /// Last Name of User 
        /// </summary>
        public string LastName { get; set; }
        /// <summary>
        /// Mobile of User
        /// </summary>
        public string Mobile { get; set; }
        /// <summary>
        /// Email Address of User
        /// </summary>
        public string EmailAddress { get; set; }
        /// <summary>
        /// Country of User
        /// </summary>
        public string Country { get; set; }
        /// <summary>
        /// State of User
        /// </summary>
        public string State { get; set; }
        /// <summary>
        /// City of User
        /// </summary>
        public string City { get; set; }
        /// <summary>
        /// Address of User
        /// </summary>
        public string Address { get; set; }
        /// <summary>
        /// ZipCode of User
        /// </summary>
        public int ZipCode { get; set; }

    }

    //public void UserCreated(Users request) => Events.UserCreated.Publish(request);
}
