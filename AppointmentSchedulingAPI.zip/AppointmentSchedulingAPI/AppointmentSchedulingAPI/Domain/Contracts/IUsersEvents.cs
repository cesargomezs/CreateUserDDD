﻿using AppointmentSheduling.Domain.Entities;


namespace AppointmentSheduling.Domain.Contracts
{
    public interface IUsersEvents 
    {
        List<Users> GetUsersAllAsync();
        Task AddUserAsync(Users user);
        Users GetUsersById(Guid Id);
        Users UpdateUsersById(Users user);
        string DeleteUsersById(string Id);
    }
}
