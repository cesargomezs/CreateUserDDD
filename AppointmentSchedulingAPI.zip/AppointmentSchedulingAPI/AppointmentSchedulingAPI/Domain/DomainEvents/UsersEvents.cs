﻿using AppointmentSheduling.Queries;
using AppointmentSheduling.Domain.Entities;
using AppointmentSheduling.Domain.Contracts;
using AppointmentSheduling.Domain.Repositories;


namespace AppointmentSheduling.Domain.DomainEvents
{
    public class UsersEvents : IUsersEvents
    {
        private readonly IUsersRepository usersRepository;
        private readonly UsersQueries queries;

        public UsersEvents(IUsersRepository usersRepository, UsersQueries queries)
        {
            this.usersRepository = usersRepository;
            this.queries = queries;
        }

        public List<Users> GetUsersAllAsync()
        {
           return queries.GetUsersAllAsync().Result;
        }

        public async Task AddUserAsync(Users user) =>
            await usersRepository.AddUserAsync(user);

        public Users GetUsersById(Guid Id)
        {
            return queries.GetUsersById(Id);
        }

        public Users UpdateUsersById(Users entries)
        {
            return usersRepository.UpdateUsersById(entries);
        }

        public string DeleteUsersById(string Id)
        {
            return usersRepository.DeleteUsersById(Id);
        }

    }

}
