﻿using AppointmentSheduling.Domain.Entities;

namespace AppointmentSheduling.Domain.DomainEvents
{
    public static class Events
    {
        public static readonly DomainEvent<Users> UserCreated = new DomainEvent<Users>();
    }
}
