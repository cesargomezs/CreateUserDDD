﻿using AppointmentSheduling.Domain.Entities;


namespace AppointmentSheduling.Domain.Repositories
{
    public interface IUsersRepository
    {
        Task<List<Users>> GetUsersAllAsync();
        Task AddUserAsync(Users user);
        Users GetUsersById(Guid Id);
        Users UpdateUsersById(Users user);
        string DeleteUsersById(string Id);
    }
}
