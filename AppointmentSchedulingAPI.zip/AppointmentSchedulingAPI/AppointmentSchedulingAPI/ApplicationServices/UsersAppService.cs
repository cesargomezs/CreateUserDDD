﻿using AppointmentSheduling.DTOs;
using AppointmentSheduling.Domain.Entities;
using AppointmentSheduling.Domain.Contracts;


namespace AppointmentSheduling.ApplicationServices
{
    public class UsersAppService
    {

        private readonly IUsersEvents events;

        public UsersAppService(IUsersEvents events) { 

            this.events = events;
        }

        public RequestResult<List<Users>> GetUsersAllAsync()
        {   
            var getUsers = events.GetUsersAllAsync();
            return RequestResult<List<Users>>.CreateSuccessful(getUsers);
        }

        public async Task AddUser(Users user) =>
            await events.AddUserAsync(user);
          

        public RequestResult<Users> GetUsersById(Guid Id)
        {
            try
            {
                var response = events.GetUsersById(Id);
                if (response==null)
                {
                    return RequestResult<Users>.CreateError(errorMessage: "No data in storage");
                }
                    return RequestResult<Users>.CreateSuccessful(response);

            }
            catch (Exception)
            {

                return RequestResult<Users>.CreateError(errorMessage: "No se encontraron registros");
            }
        }

        public RequestResult<Users> UpdateUsersById(Users entries)
        {  
            try
            {
                var user = events.UpdateUsersById(entries);

                if (user.Id == Guid.Empty)
                {
                    return RequestResult<Users>.CreateError(errorMessage: "No data in storage");
                }
                return RequestResult<Users>.CreateSuccessful(user);
            }
            catch (Exception ex) {

                    return RequestResult<Users>.CreateError(errorMessage:"No se encontraron registros");
            }
        }

        public RequestResult<string> DeleteUsersById(string Id)
        {
            try
            {
                var user = events.DeleteUsersById(Id);
                return RequestResult<string>.CreateSuccessful(user);
            }
            catch (Exception)
            {
                return RequestResult<string>.CreateError(errorMessage: "No se encontraron registros");
            }
        }

    }
}
